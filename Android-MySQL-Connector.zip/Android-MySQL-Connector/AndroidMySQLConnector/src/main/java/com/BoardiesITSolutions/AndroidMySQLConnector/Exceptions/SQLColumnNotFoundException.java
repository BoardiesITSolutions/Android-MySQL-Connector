package com.BoardiesITSolutions.AndroidMySQLConnector.Exceptions;

public class SQLColumnNotFoundException extends Exception
{
    public SQLColumnNotFoundException(String message)
    {
        super(message);
    }
}

